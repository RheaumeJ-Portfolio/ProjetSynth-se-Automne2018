﻿namespace Game.Entity.Enemies.Boss.Edgar
{
    class JumpPhase : SequentialPhase
    {
        protected override void Init()
        {

        }
    }
}
