﻿namespace Game.Entity.Enemies.Boss.Jacob
{
    class JacobController : BossController
    {
    }
}