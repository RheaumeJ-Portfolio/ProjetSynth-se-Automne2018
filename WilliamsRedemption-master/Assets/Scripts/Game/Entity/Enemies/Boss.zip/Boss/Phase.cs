﻿using UnityEngine;

namespace Game.Entity.Enemies.Boss
{
    public abstract class Phase : State
    {

    }
}
